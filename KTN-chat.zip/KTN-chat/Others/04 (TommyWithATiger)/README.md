#Communications - Services and Networks

This is a chat client/server project in TTM4100 - Communications - Services and Networks at NTNU, spring 2016. The project is written in Python 3.5 and uses JSON to send messages between client and server. The communication between server and client follows the protocol given in the file "Project description.pdf"

##KTN1 - Design

The design part of the project. Contains class diagrams, sequence diagrams and descriptions for the design.

##KTN2 - Coding

The implementation part of the project. Contains the code for the client and server.