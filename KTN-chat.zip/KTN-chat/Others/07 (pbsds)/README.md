# TTM4100-Chat
A university asssignment where we as a group create a simple threaded Chat server and client following a certain communication protocol

The people involved:
* Peder Bergebakken Sundt (pbsds)
* Silje Sævig (SuperSilje)
* Andreas Suorza Sørensen (andsuor)
* Au-Dung Vuong (audungv)