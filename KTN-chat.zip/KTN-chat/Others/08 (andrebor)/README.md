# ktn_chat
Small group project in course TTM4100 @ NTNU

A quite terrible and very buggy implementation of a server-client chat program based on provided skeleton code written in python.
