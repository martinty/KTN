# ktnprosjekt
KTN-prosjekt for gruppe 13.
