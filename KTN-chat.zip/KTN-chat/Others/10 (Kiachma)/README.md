TTM4100
=======

Python application made as a group project in the courseTTM4100 Communication - Services and Networks @ NTNU

The task was to design and implement a Chat Client and a Chat 
Server according to a provided protocol.


Class-diagram
------

![alt tag](https://raw.github.com/Kiachma/TTM4100/master/ClassDiagram.png)


