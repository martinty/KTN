# -*- coding: utf-8 -*-
import socket, json, sys, codecs
from MessageReceiver import MessageReceiver
from MessageParser import MessageParser

class Client:
    """
    This is the chat client class
    """

    def __init__(self, host, server_port):
        """
        This method is run when creating a new Client object
        """

        # Set up the socket connection to the server
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.host = host
        self.server_port = server_port
        self.MParser = MessageParser()
        # TODO: Finish init process with necessary code
        self.run()

    def run(self):
        # Initiate the connection to the server
        self.connection.connect((self.host, self.server_port))
        self.thread = MessageReceiver(self, self.connection)
        self.thread.start()

        while True:
            textInput = input().split(' ', 1)
            if(len(text) > 0 and len(text) < 3):
                if(len(text)==1):
                    text.append('')
                if(text[0] == 'login'):
                    payload=json.dumps({'request': 'login', 'content': text[1]})
                    self.send_payload(payload)
                elif(text[0] == 'logout'):
                    self.disconnect()
                elif(text[0] == 'names'):
                    payload=json.dumps({'request': 'names'})
                    self.send_payload(payload)
                elif(text[0] == 'help'):
                    payload=json.dumps({'request': 'help'})
                    self.send_payload(payload)
                elif(text[0] == 'msg'):
                    payload=json.dumps({'request': 'msg', 'content': text[1]})
                    self.send_payload(payload)
                else:
                    print('Unknown command, type "help" for help')
            else:
                print('Unknown command, type "help" for help')
                        
        
    def disconnect(self):
        # TODO: Handle disconnection
        payload = json.dumps({'requst': 'logout'})
        self.send_payload(payload)
        sys.exit()

    def receive_message(self, message):
        print self.MParser.parse(message)



        # TODO: Handle incoming message
        msg = message
        if(msg['response'] == 'info'):
            print('[Info]', msg['content'])
        elif(msg['response'] == 'error'):
            print('[Error]', msg['content'])
        elif(msg['response'] == 'msg'):
            print(recv['sender']+':', msg['content'])
        elif(msg['response'] == 'history'):
            for content in msg['content']:
                self.receive_message(content)
        else:
            print('Server of of bounds:', msg)

    def send_payload(self, data):
        # TODO: Handle sending of a payload
        self.connection.send(bytes(data, 'UTF-8'))
        
    # More methods may be needed!

if __name__ == '__main__':
    """
    This is the main method and is executed when you type "python Client.py"
    in your terminal.

    No alterations is necessary
    """
    client = Client('localhost', 9998)