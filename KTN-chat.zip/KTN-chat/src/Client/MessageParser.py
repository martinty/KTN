import json

class MessageParser():
    def __init__(self):

        self.possible_responses = {
            'message': self.parse_message,
            'history': self.parse_history,
            'help': self.parse_help,
            'error': self.parse_error,
            'info': self.parse_info,
        }

    def parse(self, payload):
        payload = json.loads(payload)

        if payload['response'] in self.possible_responses:
            return self.possible_responses[payload['response']](payload)
        else:
            print 'Response not valid'

    def parse_error(self, payload):
        return (payload['response'], payload['timestamp'], payload['sender'], payload['content'])
    
    def parse_info(self, payload):
        return (payload['response'], payload['timestamp'], payload['sender'], payload['content'])

    def parse_history(self, payload):
        history = payload['content']
        str = ""
        for payload in history ['content']:
            payload = json.loads(payload)
            str += "\n".format(self.parse_message(payload))
        return (str)

    def parse_message(self, payload):
         return (payload['response'], payload['timestamp'], payload['sender'], payload['content'])

    def parse_help(self, payload):
        return (payload['response'], payload['timestamp'], payload['sender'], payload['content'])
    


# Include more methods for handling the different responses... 
