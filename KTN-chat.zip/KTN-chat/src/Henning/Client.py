# -*- coding: utf-8 -*-
import socket, json
from MessageReceiver import MessageReceiver
from MessageParser import MessageParser


class Client:
    '''
    This is the chat client class
    '''
    def __init__(self, host, server_port):
        '''
        This method is run when creating a new Client object
        '''

        # Set up the socket connection to the server
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_port = server_port
        self.host = host
        
        # TODO: Finish init process with necessary code
        self.run()


    def run(self):
        # Initiate the connection to the server

        self.connection.connect((self.host, self.server_port))
        MessageReceiver(self, self.connection)

        userName = raw_input('Username: ')
        self.login(userName)
        print('Hello and welcome to our chat-server! You are now logged in and the requests available are: login, msg, history, names and logout')

        while True:
            msg = raw_input('> ').split()
            self.create_request(msg[0], ' '.join(msg[1:]))


    def disconnect(self):
        # TODO: Handle disconnection

        self.connection.close()


    def receive_message(self, message):
        # TODO: Handle incoming message

        parser = MessageParser()
        parser.parse(message)


    def send_payload(self, data):
        # TODO: Handle sending of a payload

        self.connection.send(json.dumps(data))


    def login(self, username):
        
        self.create_request('login', username)
        self.username = username


    def send_message(self, message):

        self.create_request('msg', message)


    def help(self):

        self.create_request('help')


    def logout(self):

        self.create_request('logout', self.username)


    def create_request(self, request, content):

        payload = {'request': request, 'content': content,}
        self.send_payload(payload)

    # More methods may be needed!


if __name__ == '__main__':
    '''
    This is the main method and is executed when you type 'python Client.py'
    in your terminal.

    No alterations are necessary
    '''
    client = Client('localhost', 9998)
    