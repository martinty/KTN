import json


class MessageParser:

    def __init__(self):

        self.possible_responses = {
            'error': self.parse_error,
            'info': self.parse_info,
            'history': self.parse_history,
            'message': self.parse_message,
        }


    def parse(self, payload):

        payload = json.loads(payload) # decode the JSON object

        if payload['response'] in self.possible_responses:
            return self.possible_responses[payload['response']](payload)
        else:
            print('Invalid response!') # Response not valid


    def parse_error(self, payload):

        print(payload['timestamp'] + '\t' + 'Error: ' + payload['content'])


    def parse_info(self, payload):

        print(payload['timestamp'] + '\t' + payload['sender'] + ': ' + payload['content'])


    def parse_history(self, payload):
        
        for index in payload['content']:
            print(payload['sender'] + ': '+ index)


    def parse_message(self, payload):

        print(payload['timestamp'] + '\t' + payload['sender'] + ': ' + payload['content'])

    # Include more methods for handling the different responses... 