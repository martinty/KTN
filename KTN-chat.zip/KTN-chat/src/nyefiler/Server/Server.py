# -*- coding: utf-8 -*-
import SocketServer as socketserver
import re
import json
import time

"""
Variables and functions that must be used by all the ClientHandler objects
must be written here (e.g. a dictionary for connected clients)
"""


class ClientHandler(socketserver.BaseRequestHandler):
    """
    This is the ClientHandler class. Everytime a new client connects to the
    server, a new ClientHandler object will be created. This class represents
    only connected clients, and not the server itself. If you want to write
    logic for the server, you must write it outside this class
    """

    def handle(self):
        """
        This method handles the connection between a client and the server.
        """
        self.ip = self.client_address[0]
        self.port = self.client_address[1]
        self.connection = self.request
        self.user = None
        server.connections.append(self)

        # Loop that listens for messages from the client
        while True:
            received_string = self.connection.received_string(4096)
            request = received_string['request']

            if(request == 'login'):
                self.login(received_string)
            elif(request == 'logout'):
                if(self.user == None):
                    self.error('Not logged in')
                else:
                    self.logout()
                    break
            elif(request == 'msg'):
                if(self.user == None):
                    self.error('Not logged in')
                else:
                    self.message(received_string)
                pass
            elif(request== 'names'):
                if(self.user == None):
                    self.error('Not logged in')
                else:
                    self.names()
            elif(request== 'help'):
                self.help()
            else:
                self.error('Unknown request')

            def history(self):
                payload = {'timestamp': int(time.time()), 'sender': '[Server]', 'response': 'history', 'content': []}
                for message in server.messages:
                    payload['content'].append(message)
                self.send_payload(json.dumps(payload))


            def login(self, received_string):
                if re.match("^[A-Za-z0-9_-]+$", received_string['content']):
                    print(recv['content'],'logged in')
                    self.user = received_string['content']
                    self.history()
                    msg = {'timestamp': int(time.time()), 'sender': '[Server]', 'response': 'info', 'content': self.user+' connected'}
                    payload = json.dumps(msg)
                    for connected in server.connections:
                        if(connected.user != None):
                            connected.send_payload(payload)
                    server.messages.append(msg)
                else:
                    self.error('Invalid username')



            def help(self):
                payload=json.dumps({'timestamp': int(time.time()), 'sender': '[Help]', 'response': 'info', 'content': 'Avaleable commands: login <uname>, logout, msg <message>, names, help'})
                self.send_payload(payload)

            def names(self):
                names=""
                for connected in server.connections:
                    if(connected.user != None):
                        names+=connected.user+', '
                payload=json.dumps({'timestamp': int(time.time()), 'sender': '[Server]', 'response': 'info', 'content': 'Connected users: '+names}) 
                self.send_payload(payload)
            
            def message(self, message):
                msg = {'timestamp': int(time.time()), 'sender': self.user, 'response': 'msg', 'content': recv['content']}
                payload = json.dumps(msg)   
                for connected in server.connections:
                    if(connected.user != None):
                        connected.send_payload(payload)
                server.messages.append(msg)

            def logout(self):
                server.connections.remove(self)
                self.connection.close()
                if(self.user != None):
                    print(self.user,'logged out')
                    msg = {'timestamp': int(time.time()), 'sender': '[Server]', 'response': 'info', 'content': self.user+' disconnected'}
                    payload = json.dumps(msg)   
                    for connected in server.connections:
                        if(connected.user != None):
                            connected.send_payload(payload)
                    server.messages.append(msg)

            def send_payload(self, data):
                if data["response"] == "message":
                    for user in server.users:
                        if user != self.username:
                            server.users[user].sendall(json.dumps(data))
                else:
                    self.request.sendall(json.dumps(data))


            # TODO: Add handling of received payload from client


class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    """
    This class is present so that each client connected will be ran as a own
    thread. In that way, all clients will be served by the server.

    No alterations are necessary
    """
    allow_reuse_address = True

    connections=[]
    messages=[]


if __name__ == "__main__":
    """
    This is the main method and is executed when you type "python Server.py"
    in your terminal.

    No alterations are necessary
    """
    HOST, PORT = 'localhost', 9998
    print ('Server running...')

    # Set up and initiate the TCP server
    server = ThreadedTCPServer((HOST, PORT), ClientHandler)
    server.serve_forever()
